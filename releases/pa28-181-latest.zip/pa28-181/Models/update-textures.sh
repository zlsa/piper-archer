#!/bin/sh

cd $1
cp textures/exterior/*.png .
cp textures/interior/*.png .
