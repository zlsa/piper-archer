#!/bin/sh

cp textures/exterior/*.png .
cp textures/interior/*.png .
